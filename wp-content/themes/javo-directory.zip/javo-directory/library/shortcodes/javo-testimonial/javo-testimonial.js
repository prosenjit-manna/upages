// When the DOM is ready, run this function
jQuery(document).ready(function($) {
  //Set the carousel options
  $('#javo-quote-carousel').carousel({
    pause: true,
    interval: 4000,
  });
});