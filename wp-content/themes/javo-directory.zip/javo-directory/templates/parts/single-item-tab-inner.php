<?php
$javo_directory_query			= new javo_get_meta( get_the_ID() );
$javo_rating					= new javo_Rating( get_the_ID() );
global
	$javo_custom_field
	, $post
	, $javo_custom_item_label
	, $javo_custom_item_tab
	, $javo_tso;
$javo_this_author				= get_userdata($post->post_author);
$javo_this_author_avatar_id		= get_the_author_meta('avatar');
$javo_directory_query			= new javo_get_meta( get_the_ID() );
$javo_rating = new javo_Rating( get_the_ID() );
?>
<div class="tabs-wrap">
	<ul id="single-tabs" class="nav nav-pills nav-justified" data-tabs="single-tabs">
		<li class="active">
			<a href="#item-detail" data-toggle="tab">
				<span class="glyphicon glyphicon-home"></span>&nbsp;
				<?php echo $javo_custom_item_label->get('about',__('About Us','javo_fr')); ?>
			</a>
		</li>
		<?php if( $javo_custom_item_tab->get('location', '') == '' ): ?>
			<li>
				<a href="#item-location" data-toggle="tab">
					<span class="glyphicon glyphicon-map-marker"></span>&nbsp;
					<?php _e($javo_custom_item_label->get('location', 'Location'), 'javo_fr'); ?>
				</a>
			</li>
		<?php endif; ?>

		<?php if( $javo_custom_item_tab->get('events', '') == '' ): ?>
			<li>
				<a href="#item-events" data-toggle="tab">
					<span class="glyphicon glyphicon-heart-empty"></span>&nbsp;
					<?php _e($javo_custom_item_label->get('events', 'Events'), 'javo_fr'); ?>
				</a>
			</li>
		<?php endif; ?>

		<?php if( $javo_custom_item_tab->get('ratings', '') == '' ): ?>
			<li>
				<a href="#item-ratings" data-toggle="tab">
					<span class="glyphicon glyphicon-star"></span>&nbsp;
					<?php _e($javo_custom_item_label->get('ratings', 'Ratings'), 'javo_fr'); ?>
				</a>
			</li>
		<?php endif; ?>

		<?php if( $javo_custom_item_tab->get('reviews', '') == '' ): ?>
			<li>
				<a href="#item-reviews" data-toggle="tab">
					<span class="glyphicon glyphicon-comment"></span>&nbsp;
					<?php _e($javo_custom_item_label->get('reviews', 'Reviews'), 'javo_fr'); ?>
				</a>
			</li>
		<?php endif; ?>
	</ul>
    <div id="javo-single-tab" class="tab-content">
        <div class="tab-pane active" id="item-detail">
           	<?php get_template_part('templates/parts/part', 'single-detail-tab');?>
        </div>
		<?php if( $javo_custom_item_tab->get('location', '') == '' ): ?>
			<div class="tab-pane" id="item-location">
				<?php get_template_part('templates/parts/part', 'single-maps');?>
				<p>&nbsp;</p>
				<?php get_template_part('templates/parts/part', 'single-contact');?>
			</div>
		<?php endif; ?>

		<?php if( $javo_custom_item_tab->get('events', '') == '' ): ?>
			<div class="tab-pane" id="item-events">
				<?php get_template_part('templates/parts/part', 'single-events');?>
			</div>
		<?php endif; ?>

		<?php if( $javo_custom_item_tab->get('ratings', '') == '' ): ?>
			<div class="tab-pane" id="item-ratings">
				<?php get_template_part('templates/parts/part', 'single-ratings-tab');?>
			</div>
		<?php endif; ?>

		<?php if( $javo_custom_item_tab->get('reviews', '') == '' ): ?>
			<div class="tab-pane" id="item-reviews">
				<?php get_template_part('templates/parts/part', 'single-reviews');?>
			</div>
		<?php endif; ?>


    </div>
</div> <!-- tabs-wrap -->

<script type="text/javascript">
    jQuery(document).ready(function ($) {
        $('#single-tabs').tab();
		// link to specific single-tabs
		var hash = location.hash
		  , hashPieces = hash.split('?')
		  , activeTab = hashPieces[0] != '' ? $('[href=' + hashPieces[0] + ']') : null;
		activeTab && activeTab.tab('show');
    });
</script>