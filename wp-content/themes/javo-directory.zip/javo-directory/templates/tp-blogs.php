<?php
/*
* Template Name: Blogs
*/
get_header();
$post_type = "post";
require_once "parts/part-template-layout.php";
get_footer();